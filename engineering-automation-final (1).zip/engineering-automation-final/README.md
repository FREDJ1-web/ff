# Engineering Automation

Professional multi-page Next.js website for Engineering Automation.

## Run locally

```bash
npm install
npm run dev
```

## Deploy to Vercel

1. Push this folder to a GitHub repository.
2. Import the repository into Vercel.
3. Deploy.

## Notes

- The legal notice and privacy pages are temporary placeholders and must be completed before public launch.
- The contact form currently posts to a demo API route and returns a success message without storing data.
