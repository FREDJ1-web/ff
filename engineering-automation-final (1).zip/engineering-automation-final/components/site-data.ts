export const site = {
  name: "Engineering Automation",
  slogan: "Automation systems for engineering offices, R&D teams and industrial SMEs.",
  email: "fredjamine81@gmail.com",
  coverage: "Worldwide",
  ctaPrimary: "Request a Diagnostic",
  ctaSecondary: "Get in Touch",
  ctaTertiary: "Book a Call",
};

export const services = [
  {
    title: "Technical Data Automation",
    description:
      "Automation of repetitive engineering data workflows from Excel, CSV files, laboratory test data, sensor exports and technical spreadsheets. We design systems that reduce manual handling, standardize outputs and accelerate technical decision-making.",
    bullets: [
      "Excel / CSV / Python workflows",
      "Automated calculations and KPIs",
      "Charts and technical deliverables",
      "Standardized output structures",
    ],
  },
  {
    title: "Technical Reporting Automation",
    description:
      "We turn fragmented analysis, raw technical data and notes into faster, more reliable reporting processes. This includes summaries, internal reports, client-facing deliverables, test reports and presentation-ready content.",
    bullets: [
      "Recurring report generation",
      "Test campaign summaries",
      "Slide-ready technical outputs",
      "Reduced manual formatting",
    ],
  },
  {
    title: "Internal AI Knowledge Systems",
    description:
      "We build internal AI assistants that help teams retrieve procedures, technical notes, project references, lessons learned and internal documentation faster, without digging through disconnected folders and files.",
    bullets: [
      "Documentation retrieval",
      "Structured internal Q&A",
      "Knowledge capitalization",
      "Faster access to technical information",
    ],
  },
  {
    title: "Technical Workflow Optimization",
    description:
      "We analyze repetitive engineering operations across study offices, R&D teams and industrial SMEs to identify where automation creates the strongest return. The result is a simpler, more reliable operating workflow.",
    bullets: [
      "Workflow assessment",
      "High-ROI automation priorities",
      "Process simplification",
      "Operational standardization",
    ],
  },
  {
    title: "Custom Python Engineering Scripts",
    description:
      "For teams needing a more technical layer, we deliver custom Python scripts and analysis modules to accelerate post-processing, recurring calculations, plotting and technical workflow execution.",
    bullets: [
      "Custom scripts",
      "Post-processing pipelines",
      "Engineering-oriented logic",
      "Maintainable delivery",
    ],
  },
  {
    title: "AI Enablement for Technical Teams",
    description:
      "We help technical organizations understand where AI can create practical value, deploy relevant use cases and introduce structured usage without hype, complexity or unnecessary tooling.",
    bullets: [
      "AI use-case identification",
      "Practical team onboarding",
      "Technical adoption support",
      "Implementation roadmap",
    ],
  },
];

export const industries = [
  {
    title: "Engineering Offices",
    text: "Study offices and consulting engineering teams that spend too much time on calculations, formatting, recurring deliverables and data-heavy workflows.",
  },
  {
    title: "R&D Teams",
    text: "Research and development environments dealing with repeated test campaigns, experimental datasets, technical synthesis and evolving documentation.",
  },
  {
    title: "Industrial SMEs",
    text: "Small and mid-sized industrial companies that need technical automation without launching large, costly digital transformation projects.",
  },
  {
    title: "Testing & Validation",
    text: "Teams producing reports, analyses and structured results from campaigns, protocols, measurements and qualification processes.",
  },
  {
    title: "Energy, Process & Environment",
    text: "Organizations operating in process engineering, energy systems, industrial performance and technical environmental studies.",
  },
  {
    title: "Methods, Quality & Industrialization",
    text: "Operational teams that need repeatable, more reliable and more efficient technical workflows across internal business processes.",
  },
];

export const offers = [
  {
    title: "Diagnostic Express",
    price: "From €490",
    description:
      "A focused review of one technical workflow to identify automation opportunities, friction points and fast-return actions.",
    items: ["Scoping discussion", "Workflow review", "Priority map", "Action recommendations"],
  },
  {
    title: "Automation Sprint",
    price: "From €1,500",
    description:
      "A first concrete automation engagement designed to deliver a visible operational gain quickly.",
    items: ["1 to 2 automation use cases", "Technical delivery", "Short documentation", "Team handover session"],
  },
  {
    title: "Premium Implementation",
    price: "From €3,000",
    description:
      "A larger engagement to structure a full technical workflow around reporting, data handling, documentation or operational automation.",
    items: ["In-depth assessment", "Workflow design", "Multi-step implementation", "Deployment support"],
  },
  {
    title: "Monthly Support",
    price: "From €900 / month",
    description:
      "Continuous improvement, maintenance and expansion of the systems already in place.",
    items: ["Enhancement requests", "Ongoing technical support", "New use cases", "Monthly review"],
  },
];

export const useCases = [
  {
    title: "Test Campaign Analysis Automation",
    text: "Automate the transformation of repeated test data into charts, indicators and standardized technical outputs.",
  },
  {
    title: "Excel / CSV Reporting Pipeline",
    text: "Turn recurring spreadsheet-based analysis into a faster reporting pipeline with less manual formatting and fewer repetitive tasks.",
  },
  {
    title: "Internal AI Procedure Assistant",
    text: "Help technical teams retrieve procedures, notes and project references in seconds instead of searching manually across folders.",
  },
  {
    title: "Engineering Office Workflow Standardization",
    text: "Standardize repetitive deliverables and technical outputs across engineering office workflows.",
  },
  {
    title: "R&D Technical Synthesis Acceleration",
    text: "Reduce the effort needed to consolidate technical notes, datasets and recurring analysis for internal decision-making.",
  },
  {
    title: "Custom Python Post-Processing",
    text: "Create dedicated scripts to automate repetitive calculations, plotting and engineering-oriented processing tasks.",
  },
];

export const resources = [
  {
    category: "Insight",
    title: "How technical teams lose time in reporting-heavy environments",
    excerpt:
      "A practical view on where engineering organizations create avoidable delays in reporting, analysis and structured deliverables.",
  },
  {
    category: "Guide",
    title: "Where AI creates real value in engineering workflows",
    excerpt:
      "Not every AI use case matters. This resource focuses on the ones that generate measurable value inside technical organizations.",
  },
  {
    category: "Framework",
    title: "A simple model for prioritizing industrial automation opportunities",
    excerpt:
      "A practical way to rank repetitive workflows by time savings, error reduction and ease of deployment.",
  },
];

export const faqs = [
  {
    q: "Do you only work with large organizations?",
    a: "No. Engineering Automation is intentionally positioned for engineering offices, R&D teams and industrial SMEs that need fast, practical gains without heavy transformation programs.",
  },
  {
    q: "Do teams need to know how to code?",
    a: "No. The systems are designed for technical users and business teams, with usable outputs, clear documentation and straightforward handover.",
  },
  {
    q: "Can you work with existing tools?",
    a: "Yes. Whenever possible, we build around current tools and workflows rather than forcing unnecessary complexity.",
  },
  {
    q: "Do you operate internationally?",
    a: "Yes. Engineering Automation serves organizations worldwide.",
  },
];
