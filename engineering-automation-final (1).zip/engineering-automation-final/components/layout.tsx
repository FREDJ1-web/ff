import Image from "next/image";
import Link from "next/link";
import { ReactNode } from "react";
import { site } from "./site-data";

const nav = [
  ["/", "Home"],
  ["/services", "Services"],
  ["/industries", "Industries"],
  ["/offers", "Offers"],
  ["/resources", "Resources"],
  ["/about", "About"],
  ["/contact", "Contact"],
] as const;

export function SiteLayout({ children, active }: { children: ReactNode; active?: string }) {
  return (
    <>
      <header className="header">
        <div className="container header-inner">
          <Link href="/" className="brand">
            <div className="brand-mark">
              <Image src="/logo.png" alt="Engineering Automation logo" width={56} height={56} className="logo-img" />
            </div>
            <div className="brand-text">
              <strong>{site.name}</strong>
              <span>{site.slogan}</span>
            </div>
          </Link>
          <nav className="nav">
            {nav.map(([href, label]) => (
              <Link key={href} href={href} className={active === href ? "active" : ""}>
                {label}
              </Link>
            ))}
          </nav>
          <Link href="/contact" className="btn btn-ghost">
            Contact Engineering Automation
          </Link>
        </div>
      </header>
      <main>{children}</main>
      <footer className="footer">
        <div className="container footer-inner">
          <div>
            <div style={{ fontWeight: 800 }}>{site.name}</div>
            <div className="subtle" style={{ marginTop: 6 }}>{site.slogan}</div>
            <div className="subtle" style={{ marginTop: 6 }}>Contact: {site.email} — Coverage: {site.coverage}</div>
          </div>
          <div className="footer-links">
            <Link href="/legal">Legal Notice</Link>
            <Link href="/privacy">Privacy</Link>
            <Link href="/resources">Resources</Link>
            <Link href="/contact">Contact</Link>
          </div>
        </div>
      </footer>
    </>
  );
}

export function PageIntro({ eyebrow, title, intro }: { eyebrow: string; title: string; intro: string }) {
  return (
    <section className="page-hero">
      <div className="container page-intro">
        <div className="eyebrow">{eyebrow}</div>
        <h1 style={{ marginTop: 18 }}>{title}</h1>
        <p className="lead" style={{ marginTop: 24 }}>{intro}</p>
      </div>
    </section>
  );
}
