"use client";

import { FormEvent, useState } from "react";

export function ContactForm() {
  const [status, setStatus] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setStatus(null);
    const formData = new FormData(e.currentTarget);
    const payload = Object.fromEntries(formData.entries());

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      setStatus(data.message || "Request sent.");
      e.currentTarget.reset();
    } catch {
      setStatus("Something went wrong. Please contact fredjamine81@gmail.com directly.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form className="form-grid" onSubmit={onSubmit}>
      <input name="name" className="input" placeholder="Full name" required />
      <input name="email" type="email" className="input" placeholder="Business email" required />
      <input name="company" className="input" placeholder="Company" required />
      <select name="orgType" className="select" defaultValue="">
        <option value="" disabled>Type of organization</option>
        <option>Engineering office</option>
        <option>R&D team</option>
        <option>Industrial SME</option>
        <option>Other technical organization</option>
      </select>
      <select name="need" className="select" defaultValue="">
        <option value="" disabled>Main need</option>
        <option>Technical data automation</option>
        <option>Reporting automation</option>
        <option>Internal AI assistant</option>
        <option>Workflow optimization</option>
        <option>Custom Python scripts</option>
        <option>AI enablement</option>
      </select>
      <select name="budget" className="select" defaultValue="">
        <option value="" disabled>Estimated budget</option>
        <option>Below €1,500</option>
        <option>€1,500 – €3,000</option>
        <option>€3,000 – €8,000</option>
        <option>€8,000+</option>
      </select>
      <select name="timeline" className="select" defaultValue="">
        <option value="" disabled>Preferred timeline</option>
        <option>As soon as possible</option>
        <option>Within 1 month</option>
        <option>Within 3 months</option>
        <option>Exploratory discussion</option>
      </select>
      <textarea name="message" className="textarea" placeholder="Describe your workflow, reporting challenge, technical data issue or documentation bottleneck." required />
      <label className="note" style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
        <input name="consent" type="checkbox" required style={{ marginTop: 4 }} />
        <span>I understand that this form is a demonstration placeholder. Privacy notice and data processing details must be finalized before public launch.</span>
      </label>
      <button disabled={loading} className="btn btn-primary" type="submit">
        {loading ? "Sending..." : "Send Request"}
      </button>
      {status ? <div className="status">{status}</div> : null}
    </form>
  );
}
