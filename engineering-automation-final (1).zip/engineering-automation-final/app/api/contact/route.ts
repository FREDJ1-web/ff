import { NextResponse } from "next/server";

export async function POST() {
  return NextResponse.json({
    ok: true,
    message:
      "Demo request received. Before public launch, connect this form to email, CRM or automation tooling and finalize the privacy notice.",
  });
}
