import { PageIntro, SiteLayout } from "@/components/layout";
import { services } from "@/components/site-data";

export default function ServicesPage() {
  return (
    <SiteLayout active="/services">
      <PageIntro
        eyebrow="Services"
        title="Technical automation services designed for operational value"
        intro="Engineering Automation focuses on practical use cases that reduce manual work, improve consistency and create measurable gains inside technical organizations."
      />
      <section className="section">
        <div className="container grid grid-2">
          {services.map((service) => (
            <div key={service.title} className="card">
              <h3>{service.title}</h3>
              <p className="text" style={{ marginTop: 16 }}>{service.description}</p>
              <div className="list">
                {service.bullets.map((bullet) => (
                  <div key={bullet} className="list-item">{bullet}</div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
