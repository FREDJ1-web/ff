import { PageIntro, SiteLayout } from "@/components/layout";
import { industries } from "@/components/site-data";

export default function IndustriesPage() {
  return (
    <SiteLayout active="/industries">
      <PageIntro
        eyebrow="Industries"
        title="Built for engineering offices, R&D teams and industrial SMEs"
        intro="The company is positioned for organizations where technical data, recurring reports, engineering knowledge and repetitive workflows create operational friction."
      />
      <section className="section">
        <div className="container grid grid-3">
          {industries.map((industry) => (
            <div key={industry.title} className="card">
              <h3>{industry.title}</h3>
              <p className="text" style={{ marginTop: 16 }}>{industry.text}</p>
            </div>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
