import { PageIntro, SiteLayout } from "@/components/layout";
import { resources } from "@/components/site-data";

export default function ResourcesPage() {
  return (
    <SiteLayout active="/resources">
      <PageIntro
        eyebrow="Resources"
        title="A credibility and education layer designed for future growth"
        intro="This section is intentionally included from the start to support future SEO, thought leadership and lead generation."
      />
      <section className="section">
        <div className="container grid grid-3">
          {resources.map((resource) => (
            <div key={resource.title} className="card">
              <div className="eyebrow">{resource.category}</div>
              <h3 style={{ marginTop: 14 }}>{resource.title}</h3>
              <p className="text" style={{ marginTop: 16 }}>{resource.excerpt}</p>
              <div className="list-item" style={{ marginTop: 18 }}>
                Placeholder resource card — to be replaced later with real articles, guides or downloadable assets.
              </div>
            </div>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
