import { PageIntro, SiteLayout } from "@/components/layout";

export default function AboutPage() {
  return (
    <SiteLayout active="/about">
      <PageIntro
        eyebrow="About"
        title="A company focused on practical automation for technical organizations"
        intro="Engineering Automation is positioned as a specialized company helping engineering offices, R&D teams and industrial SMEs transform repetitive technical work into more scalable and reliable operating systems."
      />
      <section className="section">
        <div className="container split">
          <div className="card spaced">
            <p className="text">
              The company is built around a simple principle: technical teams should not spend high-value engineering time on low-value repetitive handling, formatting, searching and restructuring work when better systems can be implemented.
            </p>
            <p className="text">
              Engineering Automation combines an engineering-oriented mindset with automation, AI and structured workflow design to create solutions that are practical, lightweight and usable in real technical environments.
            </p>
            <p className="text">
              The positioning is intentionally international and sector-focused, with a value proposition built around time savings, error reduction, standardized deliverables and stronger use of technical data.
            </p>
          </div>
          <div className="card-soft spaced">
            <div className="eyebrow">Core principles</div>
            {[
              "Operational usefulness over AI hype",
              "High-value fit for technical organizations",
              "Lightweight systems with fast practical impact",
              "Clear communication and professional execution",
              "Scalable service foundation for future growth",
            ].map((item) => (
              <div key={item} className="list-item">{item}</div>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
