import Link from "next/link";
import { SiteLayout } from "@/components/layout";
import { faqs, services, site, useCases } from "@/components/site-data";

export default function HomePage() {
  return (
    <SiteLayout active="/">
      <section className="container hero">
        <div>
          <div className="badge">Worldwide technical automation services</div>
          <h1 style={{ marginTop: 24 }}>{site.slogan}</h1>
          <p className="lead" style={{ marginTop: 28 }}>
            Engineering Automation helps technical organizations reduce manual work, improve reporting quality,
            standardize outputs and make better use of engineering data through practical automation systems powered by AI and technical workflows.
          </p>
          <div className="btn-row" style={{ marginTop: 36 }}>
            <Link href="/contact" className="btn btn-primary">{site.ctaPrimary}</Link>
            <Link href="/contact" className="btn btn-secondary">{site.ctaSecondary}</Link>
            <Link href="/contact" className="btn btn-ghost">{site.ctaTertiary}</Link>
          </div>
          <div className="metric-grid">
            {[
              ["Time Savings", "Reduce repetitive technical work across data, reporting and documentation workflows."],
              ["Error Reduction", "Increase consistency and reduce manual handling across recurring deliverables."],
              ["Standardized Outputs", "Build reliable, repeatable processes for reports, calculations and technical outputs."],
              ["Better Data Use", "Turn scattered engineering data into structured operational value."],
            ].map(([title, text]) => (
              <div key={title} className="metric">
                <strong>{title}</strong>
                <span>{text}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="card-soft spaced">
          <div className="eyebrow">Core fit</div>
          <div className="panel-title">Where we create immediate value</div>
          {[
            "Automate recurring analysis from Excel, CSV files and technical datasets",
            "Accelerate technical reporting and standardize repetitive deliverables",
            "Create internal AI assistants for procedures, notes and technical references",
            "Reduce friction in engineering office and R&D workflows without heavy transformation",
          ].map((item) => (
            <div key={item} className="list-item">{item}</div>
          ))}
        </div>
      </section>

      <section className="section-tight">
        <div className="container">
          <div className="page-intro">
            <div className="eyebrow">Core services</div>
            <h2 style={{ marginTop: 16 }}>Technical automation designed for practical operational value</h2>
            <p className="lead" style={{ marginTop: 20 }}>
              The company is positioned for engineering offices, R&D teams and industrial SMEs that want a serious, technical partner rather than generic AI messaging.
            </p>
          </div>
          <div className="grid grid-3" style={{ marginTop: 32 }}>
            {services.map((service) => (
              <div key={service.title} className="card">
                <h3>{service.title}</h3>
                <p className="text" style={{ marginTop: 16 }}>{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container card">
          <div className="eyebrow">Use cases</div>
          <h2 style={{ marginTop: 16 }}>Practical examples of where Engineering Automation fits</h2>
          <div className="grid grid-3" style={{ marginTop: 28 }}>
            {useCases.map((item) => (
              <div key={item.title} className="list-item" style={{ padding: "1.2rem" }}>
                <strong style={{ display: "block", marginBottom: 10 }}>{item.title}</strong>
                <span className="subtle" style={{ lineHeight: 1.7 }}>{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-tight">
        <div className="container split">
          <div className="card spaced">
            <div className="eyebrow">Approach</div>
            <h2 style={{ marginTop: 16 }}>A practical, structured delivery model</h2>
            {[
              ["1. Diagnose", "We identify repetitive technical work, priority bottlenecks and high-return automation opportunities."],
              ["2. Design", "We define the target workflow, outputs, user logic and delivery structure."],
              ["3. Deploy", "We implement a practical system using AI, Python, structured workflows and lightweight tools."],
              ["4. Adopt", "We document usage, support adoption and refine the system as operational needs evolve."],
            ].map(([title, text]) => (
              <div key={title} className="list-item" style={{ padding: "1.15rem" }}>
                <strong style={{ display: "block", marginBottom: 8 }}>{title}</strong>
                <span className="subtle" style={{ lineHeight: 1.7 }}>{text}</span>
              </div>
            ))}
          </div>

          <div className="card-soft spaced">
            <div className="eyebrow">FAQ</div>
            <h2 style={{ marginTop: 16 }}>Key questions prospects usually ask</h2>
            {faqs.map((item) => (
              <div key={item.q} className="list-item" style={{ padding: "1.15rem" }}>
                <strong style={{ display: "block", marginBottom: 8 }}>{item.q}</strong>
                <span className="subtle" style={{ lineHeight: 1.7 }}>{item.a}</span>
              </div>
            ))}
            <div className="btn-row" style={{ marginTop: 8 }}>
              <Link href="/offers" className="btn btn-primary">Explore Offers</Link>
              <Link href="/contact" className="btn btn-secondary">Get in Touch</Link>
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
