import { ContactForm } from "@/components/contact-form";
import { PageIntro, SiteLayout } from "@/components/layout";
import { site } from "@/components/site-data";

export default function ContactPage() {
  return (
    <SiteLayout active="/contact">
      <PageIntro
        eyebrow="Contact"
        title="Let’s discuss your automation needs"
        intro="The contact experience is designed to support lead qualification, professional positioning and future automation."
      />
      <section className="section">
        <div className="container split">
          <div className="card spaced">
            <h3>{site.name}</h3>
            <p className="text">{site.slogan}</p>
            <div className="list">
              <div className="list-item">Email: {site.email}</div>
              <div className="list-item">Coverage: {site.coverage}</div>
              <div className="list-item">Service model: Remote-first / project-based</div>
            </div>
            <div className="btn-row">
              <a href={`mailto:${site.email}`} className="btn btn-primary">{site.ctaPrimary}</a>
              <a href={`mailto:${site.email}`} className="btn btn-secondary">{site.ctaSecondary}</a>
              <a href={`mailto:${site.email}`} className="btn btn-ghost">{site.ctaTertiary}</a>
            </div>
          </div>
          <div className="card-soft">
            <ContactForm />
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
