import { PageIntro, SiteLayout } from "@/components/layout";
import { offers } from "@/components/site-data";

export default function OffersPage() {
  return (
    <SiteLayout active="/offers">
      <PageIntro
        eyebrow="Offers"
        title="Structured engagement formats with transparent entry points"
        intro="Pricing is intentionally shown as starting ranges to keep the site credible while allowing room for complexity, data volume and deployment depth."
      />
      <section className="section">
        <div className="container grid grid-4">
          {offers.map((offer, index) => (
            <div key={offer.title} className={index === 1 ? "card-soft" : "card"}>
              <h3>{offer.title}</h3>
              <div style={{ marginTop: 16, fontSize: "1.9rem", fontWeight: 900, color: "var(--accent)" }}>{offer.price}</div>
              <p className="text" style={{ marginTop: 16 }}>{offer.description}</p>
              <div className="list">
                {offer.items.map((item) => (
                  <div key={item} className="list-item">{item}</div>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className="container" style={{ marginTop: 24 }}>
          <div className="card note">
            Final scope, timelines and pricing depend on technical complexity, number of users, data volume,
            required outputs and support expectations. A custom quote can be prepared after the first discussion.
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
