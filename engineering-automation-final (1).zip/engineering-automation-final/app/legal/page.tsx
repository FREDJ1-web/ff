import { PageIntro, SiteLayout } from "@/components/layout";
import { site } from "@/components/site-data";

export default function LegalPage() {
  return (
    <SiteLayout>
      <PageIntro
        eyebrow="Legal Notice"
        title="Temporary legal notice placeholder"
        intro="This page is intentionally included now so the site structure respects the legal layer that will need to be completed before public launch."
      />
      <section className="section">
        <div className="container card spaced">
          <p className="text"><strong style={{ color: "white" }}>Company / Brand:</strong> {site.name}</p>
          <p className="text"><strong style={{ color: "white" }}>Contact email:</strong> {site.email}</p>
          <p className="text"><strong style={{ color: "white" }}>Coverage:</strong> {site.coverage}</p>
          <p className="text">
            This legal notice is a temporary placeholder and must be updated before public publication with the official company information, legal form, registration information, publication director details and hosting information.
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}
