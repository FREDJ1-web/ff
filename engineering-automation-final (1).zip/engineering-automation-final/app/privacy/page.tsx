import { PageIntro, SiteLayout } from "@/components/layout";

export default function PrivacyPage() {
  return (
    <SiteLayout>
      <PageIntro
        eyebrow="Privacy"
        title="Temporary privacy notice placeholder"
        intro="A privacy page is included by design because the site contains a contact form and is intended for professional lead collection."
      />
      <section className="section">
        <div className="container card spaced">
          <p className="text">
            This privacy notice is a temporary placeholder. Before public launch, it must specify what personal data is collected, for what purpose, how long it is retained, how users can exercise their rights and how contact form data is processed.
          </p>
          <p className="text">
            If analytics, cookies, CRM integrations or appointment scheduling tools are added later, this page and the site consent logic should be updated accordingly.
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}
